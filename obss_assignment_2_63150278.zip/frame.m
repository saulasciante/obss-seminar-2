
sePE = main('tpehg1163', 12);
sePL = main('tpehg1007', 12);
seTE = main('tpehg1070', 12);
seTL = main('tpehg1022', 12);
sePL2 = main('tpehg1163', 8);